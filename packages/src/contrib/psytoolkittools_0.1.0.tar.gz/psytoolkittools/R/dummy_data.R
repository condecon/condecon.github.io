data = data.frame(
  age = c(19,60,30,34),
  group1 = c("G11.txt", NA, "G12.txt", NA),
  group2 = c(NA, "G21.txt", NA, "G22.txt")
)
library(readr)
readr::write_csv(data, file = "data.csv")
